Name: minitiff
Summary: Minimal I/O interface to the Tagged Image File Format (TIFF)
Author: Cosmin Truta
Version: 0.1
License: zlib

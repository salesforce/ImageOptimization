                       =================================
                       AdvanceCOMP Compression Utilities
                       =================================

AdvanceCOMP contains recompression utilities for your .zip archives,
.png images, .mng video clips and .gz files.

It runs in Linux, Mac OS X, DOS, Windows and in all the other
Unix like platforms.

The official site of AdvanceCOMP is:

    http://advancemame.sourceforge.net

This package contains:
    advzip - Recompression and test utility for zip files
    advpng - Recompression utility for png files
    advmng - Recompression utility for mng files
    advdef - Recompression utility for deflate streams in .png, .mng and .gz files
